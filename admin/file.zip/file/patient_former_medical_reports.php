	
		<div class="row">  
				<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">               
                <div class="card-body">                    
				  
					<span class="h3 text-capitalize"> 
						<i class="fa fa-comment text-success "> </i> <?php echo $myname; ?>  &nbsp; medical reports 
					</span> &nbsp;  <span class="h3 badge badge-outline-success font-16 ">  <i class="fa fa-building text-primary"> </i> <?php echo $myhsp; ?> : <?php echo $mytype; ?>  </span> &nbsp;  <span class="badge badge-info font-16 h3"> :  <i class="fa fa-calendar text-success"> </i> <?php #echo $mydob; ?>  </span> <br/>	<br/>	 
				<?php ?>

		<!-- <h5 class="card-title mb-4"> Ticket No. <?php echo $ticket_no;?> </h5> -->
		  <div class="fluid-container">
		  <?php $comments = $dbm->getFields($dbm->select('tickets_converse',array('ref_no'=>$myhsp,'type'=>$mytype2),array('time_c'),'and','desc'),
				array('sn','converse_type','complaints','diagnosis','treatment','from_user_id','date_vs','month_vs','year_vs','week_vs','time_vs'));
				echo $tot_com = count($comments['sn']).' comments found ';
				$n=0;
				if(!is_null($comments))foreach($comments['converse_type'] as $com_type) {
				?>
			
			<div class="row ticket-card mt-3 pb-2 border-bottom pb-3 mb-3">
			  <div class="col-md-1">
				<img class="img-sm rounded-circle mb-4 mb-md-0" src="../assets/images/default-user.png" alt="profile image">
			  </div>
			  <div class="col-md-4">
				<div class="d-flex">
				  <p class="text-primary mr-1 mb-0">[# <?php echo ($tot_com - $n); ?> ]</p>				  
				  <p class="mb-0 ellipsis bold"> Complaints</p>
				  
				</div>
				<p class="text-gray ellipsis mb-2 font-16">  <?php echo stripslashes($comments['complaints'][$n]); ?>
				</p> 
				<p class="text-gray"> <small class="text-mutted"> <i class="fa fa-clock-o">  </i> </small>
					<small class=" text-mutted">  <?php echo readTime(time()-$comments['time_vs'][$n]).' ago';?></small>
					</p>
			  </div>
			  
			   <div class="col-md-3 border-bottom ">
				<div class="d-flex">				  
				  <p class="mb-0 ellipsis bold"> Diagnosis</p>
				</div>
				<p class="text-gray ellipsis mb-2 font-16">  <?php echo stripslashes($comments['diagnosis'][$n]); ?>
				</p> 
			  </div>
			   
			   <div class="col-md-4 border-bottom ">
				<div class="d-flex"> 
				 <p class="mb-0 ellipsis bold">Treatment.</p>
				</div>
				<p class="text-gray ellipsis mb-2 font-16">  <?php echo stripslashes($comments['treatment'][$n]); ?>
				</p> 
			  </div>
			    
			</div> <!-- ./ row -->
			 
			<?php $n++;  } // end foreach  ?>
			
			

				
				</div> 
					
					<?php # $reports = $dbm->getFields());  ?>
					
				</div>  
			</div>	 <!-- ./ col-lg-6 -->	
			
			
			
			
		</div> <!-- </ row  -->