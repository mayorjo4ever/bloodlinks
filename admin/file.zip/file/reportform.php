<div class="row">  
			 <div class="col-md-3 grid-margin stretch-card">
               
					<div class="form-group" id="fm1" style="border:5px thin #000;">
						  <label class="bold text-info"> Select Date </label> 
						  <div class="input-group border-1" title="Date">
							<input style="font-size:16px; height:40px; " autocomplete="false" type="text" id="date_rec" name="date_rec"  class="form-control  datepicker" placeholder="Date">
							<div class="input-group-append">
							  <span class="input-group-text" style="height:40px;">
								<i class="fa fa-calendar  text-black"></i>
							  </span>
							</div>
						  </div>
						   <span class="date_recMsg"> </span>
						  </div> <!--./ form-group  -->
				</div> <!--./ col-lg-4  -->
				
				<div class="col-md-2">	  
				<div class="form-group" id="fm5" style="border:5px thin #000;">
				  <label class="bold text-info">  Report Number </label>  
				  <div class="input-group border-1" title=" Report Type ">
					<select class="form-control" style="font-size:16px; height:40px;" name="report_no" id="report_no">
					   <option value=""> ...  </option> 
					   <?php for($rpn = 1; $rpn<=50; $rpn++) { ?>
					   <option value="Male" <?php echo ($_SESSION['report_no']==$rpn)?"selected":""; ?>>  <?php echo $rpn;  ?>  </option> 
					   <?php } // end for -- loop ?>
					</select>						
					<div class="input-group-append">
					  <span class="input-group-text" style="height:40px;">
						<i class="fa fa-comment text-black"></i>
					  </span>
					</div>
				  </div>
				  <span class="genderMsg"> </span>
				</div> <!-- ./  col-md5
				-->
			</div>
				
				<div class="col-md-3">	  
				<div class="form-group" id="fm5" style="border:5px thin #000;">
				  <label class="bold text-info">  Report Type </label>  
				  <div class="input-group border-1" title=" Report Type ">
					<select class="form-control" style="font-size:16px; height:40px;" name="gender" id="gender">
					   <option value=""> ...  </option>
					   <option value="Male" <?php echo ($_SESSION['gender']=="Male")?"selected":""; ?>> Complaints </option>
					   <option value="Male" <?php echo ($_SESSION['gender']=="Male")?"selected":""; ?>> Diagnosis </option>
					   <option value="Male" <?php echo ($_SESSION['gender']=="Male")?"selected":""; ?>> Treatment </option> 
					</select>						
					<div class="input-group-append">
					  <span class="input-group-text" style="height:40px;">
						<i class="fa fa-comment text-black"></i>
					  </span>
					</div>
				  </div>
				  <span class="genderMsg"> </span>
				</div> <!-- ./  col-md5
				-->
			</div>
			
			 <div class="col-md-3">  <input type="hidden" name="report_ref" id="report_ref" for="<?php echo $myhsp; ?>" data-text="<?php echo $mytype2; ?>" />				
				  &nbsp;   &nbsp;  
					<button id="save_patient_report" name="save_patient_report" class="btn btn-success btn-lg btn-block bold ladda-button" for="<?php echo $myhsp; ?>" data-text="<?php echo $mytype2; ?>"> 
						Save Report <i class="fa fa-check"> </i>
					 </button>
				 
				 </div>
					
			 <div class="col-md-12">  
				 <textarea id='medReportTinyMice'> Report... </textarea> 
			  </div>
				  
            </div> 
		 	