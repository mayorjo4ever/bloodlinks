<?php 

	 require "usercheck.php";  	 
	
	?> 


<!DOCTYPE html>
<html lang="en">

<head>
	<?php require "admin_style_link.php";
			$myname = base64_decode($_REQUEST['n']);
			$mymilno = base64_decode($_REQUEST['mln']);
			$myhsp = base64_decode($_REQUEST['hn']);
			$mytype = base64_decode($_REQUEST['tp']);
			$mytype2 = base64_decode($_REQUEST['tp2']);
			$mydob = base64_decode($_REQUEST['db']); 
			$mydate = base64_decode($_REQUEST['dtc']); 
			$mydvs = base64_decode($_REQUEST['dvs']); 
		 
			$url2 = "?n=".$_REQUEST['n']."&mln=".$_REQUEST['mln']."&hn=".$_REQUEST['hn']."&tp=".$_REQUEST['tp']."&tp2=".$_REQUEST['tp2']."&db=".$_REQUEST['db']."&dtc=".$_REQUEST['dtc'];
	?>
	
</head>

<body>
  <div class="container-scroller">
    
	<?php require "head_nav.php"; ?>
	
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php require "sidebar_nav.php"; ?>
		
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
		
			 <?php require "patient_former_medical_reports.php"; ?>
		 
		
        	<form method="post"> 
		 <div class="row">  
			<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">               
                <div class="card-body">                    
				 <div class="col-md-12"> 
					<span class="h3 text-capitalize"> 
						
						<i class="fa fa-comment text-danger "> </i> &nbsp; add new medical reports  </span> &nbsp; 
							<br/><br/>						
						  <?php require "reportform.php"; ?>
				  </div> <!-- ./ col-md-12 --> 
			         
                </div>  <!--  ./ card-body -->  
              </div>   <!--  ./ card -->  
            </div>
			
			<!-- ./
			<div class="col-lg-4 grid-margin stretch-card">
              <div class="card">               
                <div class="card-body">                    
				 
					  
					<div class="col-md-12" id="receipt_infos"> 
						 <p> receipt info </p>	
					</div> <!--  ./ col-md-10 query_results           
                </div>  <!--  ./ card-body  
              </div>   <!--  ./ card    
            </div>  col-lg-4 --> 
			
			</form>
			
          </div> <!-- ./ row --> 
		  
		 
           
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
         
       <?php require "footer.php"; ?>
	   
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <?php require "admin_js_links.php"; ?>
  
    <!-- Plugin js for this page-->
    <script src="../assets/vendors/tinymce/tinymce.min.js"></script>
    <script src="../assets/vendors/tinymce/themes/modern/theme.js"></script>
   <!-- Custom js for this page-->
    <script src="../assets/js/shared/editorDemo.js"></script>
    <!-- End custom js for this page-->
</body>

</html>